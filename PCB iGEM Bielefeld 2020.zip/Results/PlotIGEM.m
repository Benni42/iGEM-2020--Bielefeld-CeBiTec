clear all;
close all;
clc;

%% Read Data
table = xlsread('MessungenPCB.xlsx');

time_shift = table(:,1);
freq = table(:,2);
voltage = table(:,4);
phase_shift = table(:,5);

%% Manipulate Data for plot

dt = delaunayTriangulation(freq,phase_shift);
tri = dt.ConnectivityList;
xi = dt.Points(:,1); 
yi = dt.Points(:,2); 
F = scatteredInterpolant(freq,phase_shift,voltage);
zi = F(xi,yi);

%% Plot 
figure(1);
trisurf(tri,xi,yi,zi);

shading interp;
xlabel("frequency in MHz");
ylabel("phase shift in °");
zlabel("output voltage in V");
colormap pink;
colorbar;
grid minor;


%% Manipulate Data for plot

dt = delaunayTriangulation(freq,time_shift);
tri = dt.ConnectivityList;
xi = dt.Points(:,1); 
yi = dt.Points(:,2); 
F = scatteredInterpolant(freq,time_shift,voltage);
zi = F(xi,yi);

%% Plot 
figure(2);
trisurf(tri,xi,yi,zi);

shading interp;
xlabel("frequency in MHz");
ylabel("time shift in ps");
zlabel("output voltage in V");
colormap pink;
colorbar;
grid minor;
